<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="css/.css">
    <title>O Começo</title>
</head>
<body class="body_principal">
    <div class="Topo">
		<img class="img" src="img/Max versttapen.jfif">
        <div class="menu">
			<a class="menu_inten">Historia</a>
			<a class="menu_inten">Historia</a>
			<a class="menu_inten">Historia</a>
			<a class="menu_inten">Historia</a>
			<a class="menu_inten">Historia</a>
        </div>
		<div class="login">
			<a class="menu_login">login/cadastro</a>
		</div>
	</div>

   
</body>
</html>